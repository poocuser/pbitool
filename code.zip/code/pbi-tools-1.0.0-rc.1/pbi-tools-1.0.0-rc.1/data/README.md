# Sample Data

## /external

## /Samples

| Folder | Description |
| --- | --- |
| Adventure Works DW 2020 | |
| Adventure Works DW 2020 - TE | |
| Introducing calculation groups | Sample dataset from <https://www.sqlbi.com/articles/introducing-calculation-groups/> |
